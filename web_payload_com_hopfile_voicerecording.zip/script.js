// HopFile script code properties
console.log("HopFile Engine elements loaded successfully!");